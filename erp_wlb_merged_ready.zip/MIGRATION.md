# Integrare proiect existent (FastAPI) în cPanel/Passenger-ready

- Codul tău a fost copiat în `erp_fastapi/ext_src/`.
- Aplicația activă este `erp_fastapi/main.py`,
  care scanează `ext_src` și include orice obiect `router` găsit.
- Dependențele au fost combinate în `requirements.txt`.
