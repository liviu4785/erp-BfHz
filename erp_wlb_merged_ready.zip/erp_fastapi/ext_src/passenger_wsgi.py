"""Entry point for Phusion Passenger to run the FastAPI application.

This module exposes a WSGI `application` object that wraps the
FastAPI ASGI app via a2wsgi.  Passenger will import this file and
use `application` to serve incoming HTTP requests.  All required
dependencies must be installed as specified in `requirements.txt`.

Environment variables for database configuration and third‑party
integrations are expected to be provided either via the `.env` file
or using `PassengerEnvVar` directives in `.htaccess`.
"""

import os
import sys

# Ensure the application root is on sys.path.  This allows Python
# to find the `erp_fastapi` package when imported below.  When
# deploying on cPanel, adjust ROOT to the directory where this
# passenger_wsgi.py file resides.
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Optionally, load environment variables from a .env file using
# python-dotenv if it is installed.  This allows you to specify
# credentials in `.env` without exposing them in Apache config.  If
# python-dotenv is not installed, this silently does nothing.
try:
    from dotenv import load_dotenv  # type: ignore
except Exception:
    load_dotenv = None  # type: ignore

if load_dotenv is not None:
    env_path = os.path.join(ROOT, ".env")
    if os.path.exists(env_path):
        load_dotenv(env_path)

# Import the FastAPI app and wrap it in ASGIMiddleware to expose
# a WSGI‑compatible interface.  This approach works with Passenger's
# WSGI integration.
from a2wsgi import ASGIMiddleware  # type: ignore
from erp_fastapi.main import app as asgi_app  # type: ignore

application = ASGIMiddleware(asgi_app)