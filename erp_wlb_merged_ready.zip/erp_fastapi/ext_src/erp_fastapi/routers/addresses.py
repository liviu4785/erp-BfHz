from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.address import Address, AddressCreate, AddressUpdate
from erp_fastapi import data

router = APIRouter(prefix="/addresses", tags=["addresses"])


@router.get("/", response_model=List[Address])
def list_addresses() -> List[Address]:
    return [Address(**a) for a in data.addresses_store.values()]


@router.post("/", response_model=Address, status_code=status.HTTP_201_CREATED)
def create_address(addr_in: AddressCreate) -> Address:
    addr_id = data.generate_id("addresses")
    addr_data = addr_in.dict()
    addr_data["id"] = addr_id
    data.addresses_store[addr_id] = addr_data
    return Address(**addr_data)


@router.get("/{addr_id}", response_model=Address)
def get_address(addr_id: int) -> Address:
    if addr_id not in data.addresses_store:
        raise HTTPException(status_code=404, detail="Address not found")
    return Address(**data.addresses_store[addr_id])


@router.put("/{addr_id}", response_model=Address)
def update_address(addr_id: int, addr_in: AddressUpdate) -> Address:
    if addr_id not in data.addresses_store:
        raise HTTPException(status_code=404, detail="Address not found")
    stored = data.addresses_store[addr_id]
    update_data = addr_in.dict(exclude_unset=True)
    for key, value in update_data.items():
        stored[key] = value
    data.addresses_store[addr_id] = stored
    return Address(**stored)


@router.delete("/{addr_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_address(addr_id: int) -> None:
    if addr_id not in data.addresses_store:
        raise HTTPException(status_code=404, detail="Address not found")
    del data.addresses_store[addr_id]
    return None
