from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.person import Person, PersonCreate, PersonUpdate
from erp_fastapi import data

router = APIRouter(prefix="/people", tags=["people"])


@router.get("/", response_model=List[Person])
def list_people() -> List[Person]:
    return [Person(**p) for p in data.people.values()]


@router.post("/", response_model=Person, status_code=status.HTTP_201_CREATED)
def create_person(person_in: PersonCreate) -> Person:
    person_id = data.generate_id("people")
    person_data = person_in.dict()
    person_data["id"] = person_id
    data.people[person_id] = person_data
    return Person(**person_data)


@router.get("/{person_id}", response_model=Person)
def get_person(person_id: int) -> Person:
    if person_id not in data.people:
        raise HTTPException(status_code=404, detail="Person not found")
    return Person(**data.people[person_id])


@router.put("/{person_id}", response_model=Person)
def update_person(person_id: int, person_in: PersonUpdate) -> Person:
    if person_id not in data.people:
        raise HTTPException(status_code=404, detail="Person not found")
    stored = data.people[person_id]
    update_data = person_in.dict(exclude_unset=True)
    for key, value in update_data.items():
        stored[key] = value
    data.people[person_id] = stored
    return Person(**stored)


@router.delete("/{person_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_person(person_id: int) -> None:
    if person_id not in data.people:
        raise HTTPException(status_code=404, detail="Person not found")
    del data.people[person_id]
    return None
