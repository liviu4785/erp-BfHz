from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.role import Role, RoleCreate, RoleUpdate
from erp_fastapi import data

router = APIRouter(prefix="/roles", tags=["roles"])


@router.get("/", response_model=List[Role])
def list_roles() -> List[Role]:
    return [Role(**role) for role in data.roles.values()]


@router.post("/", response_model=Role, status_code=status.HTTP_201_CREATED)
def create_role(role_in: RoleCreate) -> Role:
    role_id = data.generate_id("roles")
    role_data = role_in.dict()
    role_data["id"] = role_id
    data.roles[role_id] = role_data
    return Role(**role_data)


@router.get("/{role_id}", response_model=Role)
def get_role(role_id: int) -> Role:
    if role_id not in data.roles:
        raise HTTPException(status_code=404, detail="Role not found")
    return Role(**data.roles[role_id])


@router.put("/{role_id}", response_model=Role)
def update_role(role_id: int, role_in: RoleUpdate) -> Role:
    if role_id not in data.roles:
        raise HTTPException(status_code=404, detail="Role not found")
    stored = data.roles[role_id]
    update_data = role_in.dict(exclude_unset=True)
    for key, value in update_data.items():
        stored[key] = value
    data.roles[role_id] = stored
    return Role(**stored)


@router.delete("/{role_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_role(role_id: int) -> None:
    if role_id not in data.roles:
        raise HTTPException(status_code=404, detail="Role not found")
    del data.roles[role_id]
    return None
