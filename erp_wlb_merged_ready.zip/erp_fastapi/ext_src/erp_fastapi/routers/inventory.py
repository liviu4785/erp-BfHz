from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.inventory import InventoryItem, InventoryItemCreate, InventoryItemUpdate
from erp_fastapi import data

router = APIRouter(prefix="/inventory", tags=["inventory"])


@router.get("/", response_model=List[InventoryItem])
def list_inventory() -> List[InventoryItem]:
    return [InventoryItem(**i) for i in data.inventory.values()]


@router.post("/", response_model=InventoryItem, status_code=status.HTTP_201_CREATED)
def create_inventory_item(item_in: InventoryItemCreate) -> InventoryItem:
    # Ensure product exists
    if item_in.product_id not in data.products:
        raise HTTPException(status_code=400, detail="Product does not exist")
    # Search if inventory already exists for this product
    for item in data.inventory.values():
        if item["product_id"] == item_in.product_id:
            raise HTTPException(status_code=400, detail="Inventory item for this product already exists")
    item_id = data.generate_id("inventory")
    item_data = item_in.dict()
    item_data["id"] = item_id
    data.inventory[item_id] = item_data
    return InventoryItem(**item_data)


@router.get("/{item_id}", response_model=InventoryItem)
def get_inventory_item(item_id: int) -> InventoryItem:
    if item_id not in data.inventory:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    return InventoryItem(**data.inventory[item_id])


@router.put("/{item_id}", response_model=InventoryItem)
def update_inventory_item(item_id: int, item_in: InventoryItemUpdate) -> InventoryItem:
    if item_id not in data.inventory:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    stored = data.inventory[item_id]
    update_data = item_in.dict(exclude_unset=True)
    for key, value in update_data.items():
        stored[key] = value
    data.inventory[item_id] = stored
    return InventoryItem(**stored)


@router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_inventory_item(item_id: int) -> None:
    if item_id not in data.inventory:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    del data.inventory[item_id]
    return None
