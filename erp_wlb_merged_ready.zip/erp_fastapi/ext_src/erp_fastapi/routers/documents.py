from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.document import Document, DocumentCreate, DocumentUpdate
from erp_fastapi import data

router = APIRouter(prefix="/documents", tags=["documents"])


@router.get("/", response_model=List[Document])
def list_documents() -> List[Document]:
    return [Document(**d) for d in data.documents_store.values()]


@router.post("/", response_model=Document, status_code=status.HTTP_201_CREATED)
def create_document(doc_in: DocumentCreate) -> Document:
    # Validate record exists if record_type provided
    record_exists = False
    if doc_in.record_type == "company" and doc_in.record_id in data.companies:
        record_exists = True
    elif doc_in.record_type == "person" and doc_in.record_id in data.people:
        record_exists = True
    elif doc_in.record_type == "product" and doc_in.record_id in data.products:
        record_exists = True
    elif doc_in.record_type == "order" and doc_in.record_id in data.orders:
        record_exists = True
    if not record_exists:
        raise HTTPException(status_code=400, detail="Record does not exist")
    doc_id = data.generate_id("documents")
    doc_data = doc_in.dict()
    doc_data["id"] = doc_id
    data.documents_store[doc_id] = doc_data
    return Document(**doc_data)


@router.get("/{doc_id}", response_model=Document)
def get_document(doc_id: int) -> Document:
    if doc_id not in data.documents_store:
        raise HTTPException(status_code=404, detail="Document not found")
    return Document(**data.documents_store[doc_id])


@router.put("/{doc_id}", response_model=Document)
def update_document(doc_id: int, doc_in: DocumentUpdate) -> Document:
    if doc_id not in data.documents_store:
        raise HTTPException(status_code=404, detail="Document not found")
    stored = data.documents_store[doc_id]
    update_data = doc_in.dict(exclude_unset=True)
    for key, value in update_data.items():
        stored[key] = value
    data.documents_store[doc_id] = stored
    return Document(**stored)


@router.delete("/{doc_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_document(doc_id: int) -> None:
    if doc_id not in data.documents_store:
        raise HTTPException(status_code=404, detail="Document not found")
    del data.documents_store[doc_id]
    return None
