from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.product import Product, ProductCreate, ProductUpdate
from erp_fastapi import data

router = APIRouter(prefix="/products", tags=["products"])


@router.get("/", response_model=List[Product])
def list_products() -> List[Product]:
    return [Product(**p) for p in data.products.values()]


@router.post("/", response_model=Product, status_code=status.HTTP_201_CREATED)
def create_product(product_in: ProductCreate) -> Product:
    product_id = data.generate_id("products")
    product_data = product_in.dict()
    product_data["id"] = product_id
    data.products[product_id] = product_data
    return Product(**product_data)


@router.get("/{product_id}", response_model=Product)
def get_product(product_id: int) -> Product:
    if product_id not in data.products:
        raise HTTPException(status_code=404, detail="Product not found")
    return Product(**data.products[product_id])


@router.put("/{product_id}", response_model=Product)
def update_product(product_id: int, product_in: ProductUpdate) -> Product:
    if product_id not in data.products:
        raise HTTPException(status_code=404, detail="Product not found")
    stored = data.products[product_id]
    update_data = product_in.dict(exclude_unset=True)
    for key, value in update_data.items():
        stored[key] = value
    data.products[product_id] = stored
    return Product(**stored)


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_product(product_id: int) -> None:
    if product_id not in data.products:
        raise HTTPException(status_code=404, detail="Product not found")
    del data.products[product_id]
    return None
