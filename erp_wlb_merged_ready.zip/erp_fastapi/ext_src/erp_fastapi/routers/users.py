from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.user import User, UserCreate, UserUpdate
from erp_fastapi import data


router = APIRouter(prefix="/users", tags=["users"])


@router.get("/", response_model=List[User])
def list_users() -> List[User]:
    """Return all users."""
    return [User(**user) for user in data.users.values()]


@router.post("/", response_model=User, status_code=status.HTTP_201_CREATED)
def create_user(user_in: UserCreate) -> User:
    """Create a new user."""
    # Simple uniqueness check on email
    if any(u["email"] == user_in.email for u in data.users.values()):
        raise HTTPException(status_code=400, detail="Email already registered")
    user_id = data.generate_id("users")
    user_data = user_in.dict(exclude={"password"})
    # In a real app, you must hash the password!
    user_data["id"] = user_id
    data.users[user_id] = user_data
    return User(**user_data)


@router.get("/{user_id}", response_model=User)
def get_user(user_id: int) -> User:
    if user_id not in data.users:
        raise HTTPException(status_code=404, detail="User not found")
    return User(**data.users[user_id])


@router.put("/{user_id}", response_model=User)
def update_user(user_id: int, user_in: UserUpdate) -> User:
    if user_id not in data.users:
        raise HTTPException(status_code=404, detail="User not found")
    stored = data.users[user_id]
    update_data = user_in.dict(exclude_unset=True)
    for key, value in update_data.items():
        stored[key] = value
    data.users[user_id] = stored
    return User(**stored)


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int) -> None:
    if user_id not in data.users:
        raise HTTPException(status_code=404, detail="User not found")
    del data.users[user_id]
    return None
