from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.order import Order, OrderCreate, OrderUpdate
from erp_fastapi import data

router = APIRouter(prefix="/orders", tags=["orders"])


@router.get("/", response_model=List[Order])
def list_orders() -> List[Order]:
    return [Order(**o) for o in data.orders.values()]


@router.post("/", response_model=Order, status_code=status.HTTP_201_CREATED)
def create_order(order_in: OrderCreate) -> Order:
    # Validate partner (client or supplier) based on order type
    # For simplicity we treat partner_id as company or person id
    if order_in.partner_id not in data.companies and order_in.partner_id not in data.people:
        raise HTTPException(status_code=400, detail="Partner does not exist")
    # Validate products exist
    for line in order_in.items:
        if line.product_id not in data.products:
            raise HTTPException(status_code=400, detail=f"Product {line.product_id} does not exist")
    order_id = data.generate_id("orders")
    order_data = order_in.dict()
    order_data["id"] = order_id
    data.orders[order_id] = order_data
    return Order(**order_data)


@router.get("/{order_id}", response_model=Order)
def get_order(order_id: int) -> Order:
    if order_id not in data.orders:
        raise HTTPException(status_code=404, detail="Order not found")
    return Order(**data.orders[order_id])


@router.put("/{order_id}", response_model=Order)
def update_order(order_id: int, order_in: OrderUpdate) -> Order:
    if order_id not in data.orders:
        raise HTTPException(status_code=404, detail="Order not found")
    stored = data.orders[order_id]
    update_data = order_in.dict(exclude_unset=True)
    # Validate updated partner if provided
    if "partner_id" in update_data:
        pid = update_data["partner_id"]
        if pid not in data.companies and pid not in data.people:
            raise HTTPException(status_code=400, detail="Partner does not exist")
    # Validate updated items if provided
    if "items" in update_data:
        for line in update_data["items"]:
            if line.product_id not in data.products:
                raise HTTPException(status_code=400, detail=f"Product {line.product_id} does not exist")
    for key, value in update_data.items():
        stored[key] = value
    data.orders[order_id] = stored
    return Order(**stored)


@router.delete("/{order_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_order(order_id: int) -> None:
    if order_id not in data.orders:
        raise HTTPException(status_code=404, detail="Order not found")
    del data.orders[order_id]
    return None
