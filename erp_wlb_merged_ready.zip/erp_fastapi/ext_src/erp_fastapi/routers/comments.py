from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.comment import Comment, CommentCreate, CommentUpdate
from erp_fastapi import data

router = APIRouter(prefix="/comments", tags=["comments"])


@router.get("/", response_model=List[Comment])
def list_comments() -> List[Comment]:
    return [Comment(**c) for c in data.comments_store.values()]


@router.post("/", response_model=Comment, status_code=status.HTTP_201_CREATED)
def create_comment(comment_in: CommentCreate) -> Comment:
    # Validate author exists
    if comment_in.author_id not in data.users:
        raise HTTPException(status_code=400, detail="Author does not exist")
    # Validate record exists (we don't know type, but we try to check known stores)
    record_exists = False
    if comment_in.record_type == "company" and comment_in.record_id in data.companies:
        record_exists = True
    elif comment_in.record_type == "person" and comment_in.record_id in data.people:
        record_exists = True
    elif comment_in.record_type == "product" and comment_in.record_id in data.products:
        record_exists = True
    elif comment_in.record_type == "order" and comment_in.record_id in data.orders:
        record_exists = True
    if not record_exists:
        raise HTTPException(status_code=400, detail="Record does not exist")
    comment_id = data.generate_id("comments")
    comment_data = comment_in.dict()
    comment_data["id"] = comment_id
    comment_data["seen_by"] = []
    data.comments_store[comment_id] = comment_data
    # Notify mentioned users (stub)
    return Comment(**comment_data)


@router.get("/{comment_id}", response_model=Comment)
def get_comment(comment_id: int) -> Comment:
    if comment_id not in data.comments_store:
        raise HTTPException(status_code=404, detail="Comment not found")
    return Comment(**data.comments_store[comment_id])


@router.put("/{comment_id}", response_model=Comment)
def update_comment(comment_id: int, comment_in: CommentUpdate) -> Comment:
    if comment_id not in data.comments_store:
        raise HTTPException(status_code=404, detail="Comment not found")
    stored = data.comments_store[comment_id]
    update_data = comment_in.dict(exclude_unset=True)
    # Only allow edit within 1 day is out of scope for skeleton
    for key, value in update_data.items():
        stored[key] = value
    data.comments_store[comment_id] = stored
    return Comment(**stored)


@router.delete("/{comment_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_comment(comment_id: int) -> None:
    if comment_id not in data.comments_store:
        raise HTTPException(status_code=404, detail="Comment not found")
    del data.comments_store[comment_id]
    return None
