from typing import List
from fastapi import APIRouter, HTTPException, status
from erp_fastapi.models.company import Company, CompanyCreate, CompanyUpdate
from erp_fastapi import data

router = APIRouter(prefix="/companies", tags=["companies"])


@router.get("/", response_model=List[Company])
def list_companies() -> List[Company]:
    return [Company(**c) for c in data.companies.values()]


@router.post("/", response_model=Company, status_code=status.HTTP_201_CREATED)
def create_company(company_in: CompanyCreate) -> Company:
    company_id = data.generate_id("companies")
    company_data = company_in.dict()
    company_data["id"] = company_id
    data.companies[company_id] = company_data
    return Company(**company_data)


@router.get("/{company_id}", response_model=Company)
def get_company(company_id: int) -> Company:
    if company_id not in data.companies:
        raise HTTPException(status_code=404, detail="Company not found")
    return Company(**data.companies[company_id])


@router.put("/{company_id}", response_model=Company)
def update_company(company_id: int, company_in: CompanyUpdate) -> Company:
    if company_id not in data.companies:
        raise HTTPException(status_code=404, detail="Company not found")
    stored = data.companies[company_id]
    update_data = company_in.dict(exclude_unset=True)
    for key, value in update_data.items():
        stored[key] = value
    data.companies[company_id] = stored
    return Company(**stored)


@router.delete("/{company_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_company(company_id: int) -> None:
    if company_id not in data.companies:
        raise HTTPException(status_code=404, detail="Company not found")
    del data.companies[company_id]
    return None
