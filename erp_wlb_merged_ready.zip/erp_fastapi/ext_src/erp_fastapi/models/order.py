from pydantic import BaseModel, Field
from typing import List, Optional


class OrderLine(BaseModel):
    product_id: int = Field(..., description="ID of the product")
    quantity: int = Field(..., ge=1, description="Quantity of the product")
    unit_price: float = Field(..., ge=0.0, description="Unit price")
    discount_percent: Optional[float] = Field(0.0, ge=0.0, description="Discount percent applied")
    vat_percent: Optional[float] = Field(0.0, ge=0.0, description="VAT percentage")

    @property
    def total(self) -> float:
        base = self.quantity * self.unit_price
        discount = base * (self.discount_percent or 0) / 100
        subtotal = base - discount
        vat = subtotal * (self.vat_percent or 0) / 100
        return subtotal + vat


class OrderBase(BaseModel):
    order_type: str = Field(..., example="sale", description="Type of order: sale, purchase, return_sale, return_purchase")
    partner_id: int = Field(..., description="ID of the client or supplier")
    date: str = Field(..., example="2025-01-01", description="Date of the order (ISO format)")
    items: List[OrderLine] = Field(default_factory=list)
    status: Optional[str] = Field("draft", description="Status of the order")


class OrderCreate(OrderBase):
    pass


class OrderUpdate(BaseModel):
    order_type: Optional[str] = None
    partner_id: Optional[int] = None
    date: Optional[str] = None
    items: Optional[List[OrderLine]] = None
    status: Optional[str] = None


class Order(OrderBase):
    id: int

    class Config:
        orm_mode = True
