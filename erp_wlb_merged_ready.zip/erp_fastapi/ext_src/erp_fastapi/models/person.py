from pydantic import BaseModel, Field
from typing import Optional, List


class PersonBase(BaseModel):
    first_name: str = Field(..., example="Ana")
    last_name: str = Field(..., example="Popescu")
    email: Optional[str] = Field(None)
    phone: Optional[str] = Field(None)
    date_of_birth: Optional[str] = Field(None, example="1990-01-01")  # ISO date format
    unique_identifier: Optional[str] = Field(None, example="1234567890123")  # CNP
    notes: Optional[str] = None
    company_ids: List[int] = Field(default_factory=list, description="Companies this person is associated with")


class PersonCreate(PersonBase):
    pass


class PersonUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    unique_identifier: Optional[str] = None
    notes: Optional[str] = None
    company_ids: Optional[List[int]] = None


class Person(PersonBase):
    id: int

    class Config:
        orm_mode = True
