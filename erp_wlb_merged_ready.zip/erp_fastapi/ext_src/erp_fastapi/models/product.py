from pydantic import BaseModel, Field
from typing import Optional


class ProductBase(BaseModel):
    name: str = Field(..., example="Carte de exemplu")
    code: Optional[str] = Field(None, example="PROD-001")
    producer: Optional[str] = Field(None)
    category: Optional[str] = Field(None)
    unit_of_measure: Optional[str] = Field(None, example="buc")
    package_unit: Optional[str] = Field(None, example="set")
    quantity_per_package: Optional[int] = Field(None)
    list_price: Optional[float] = Field(None)
    vat_percent: Optional[float] = Field(None)
    status: Optional[str] = Field(None, example="active")
    description: Optional[str] = Field(None)


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    code: Optional[str] = None
    producer: Optional[str] = None
    category: Optional[str] = None
    unit_of_measure: Optional[str] = None
    package_unit: Optional[str] = None
    quantity_per_package: Optional[int] = None
    list_price: Optional[float] = None
    vat_percent: Optional[float] = None
    status: Optional[str] = None
    description: Optional[str] = None


class Product(ProductBase):
    id: int

    class Config:
        orm_mode = True
