from pydantic import BaseModel, Field
from typing import Optional


class RoleBase(BaseModel):
    """Shared properties for a role."""

    name: str = Field(..., example="Administrator")
    description: Optional[str] = Field(None, example="Has full access to all resources")


class RoleCreate(RoleBase):
    pass


class RoleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class Role(RoleBase):
    id: int

    class Config:
        orm_mode = True
