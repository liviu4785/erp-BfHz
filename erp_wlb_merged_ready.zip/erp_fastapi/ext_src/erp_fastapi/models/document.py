from pydantic import BaseModel, Field
from typing import Optional


class DocumentBase(BaseModel):
    name: str = Field(..., example="invoice_123.pdf")
    type: str = Field(..., example="invoice", description="Type of document (invoice, AWB, contract, etc.)")
    url: Optional[str] = Field(None, example="https://example.com/invoice_123.pdf", description="Public URL where the document can be accessed")
    record_type: str = Field(..., description="Type of record the document is attached to")
    record_id: int = Field(..., description="ID of the record the document is attached to")


class DocumentCreate(DocumentBase):
    pass


class DocumentUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    url: Optional[str] = None


class Document(DocumentBase):
    id: int

    class Config:
        orm_mode = True
