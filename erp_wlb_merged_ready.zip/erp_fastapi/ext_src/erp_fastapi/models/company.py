from pydantic import BaseModel, Field
from typing import Optional, List


class CompanyBase(BaseModel):
    name: str = Field(..., example="Rolcris SRL")
    fiscal_code: Optional[str] = Field(None, example="RO12345678")
    trade_registry_number: Optional[str] = Field(None, example="J12/345/2015")
    email: Optional[str] = Field(None)
    phone: Optional[str] = Field(None, example="+40 123 456 789")
    status: Optional[str] = Field(None, example="Active")


class CompanyCreate(CompanyBase):
    pass


class CompanyUpdate(BaseModel):
    name: Optional[str] = None
    fiscal_code: Optional[str] = None
    trade_registry_number: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    status: Optional[str] = None


class Company(CompanyBase):
    id: int

    class Config:
        orm_mode = True
