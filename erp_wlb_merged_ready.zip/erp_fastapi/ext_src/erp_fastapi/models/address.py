from pydantic import BaseModel, Field
from typing import Optional


class AddressBase(BaseModel):
    country: str = Field(..., example="Romania")
    postal_code: str = Field(..., example="400001")
    county: str = Field(..., example="Cluj")
    city: str = Field(..., example="Cluj-Napoca")
    street: str = Field(..., example="Strada Memorandumului 1")
    additional_info: Optional[str] = None
    is_default: Optional[bool] = Field(False, description="Indicates whether this is the default address")
    is_billing: Optional[bool] = Field(False, description="Indicates if this is a billing address")
    is_shipping: Optional[bool] = Field(False, description="Indicates if this is a shipping address")
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    notes: Optional[str] = None


class AddressCreate(AddressBase):
    pass


class AddressUpdate(BaseModel):
    country: Optional[str] = None
    postal_code: Optional[str] = None
    county: Optional[str] = None
    city: Optional[str] = None
    street: Optional[str] = None
    additional_info: Optional[str] = None
    is_default: Optional[bool] = None
    is_billing: Optional[bool] = None
    is_shipping: Optional[bool] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    notes: Optional[str] = None


class Address(AddressBase):
    id: int

    class Config:
        orm_mode = True
