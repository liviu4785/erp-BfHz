from pydantic import BaseModel, Field
from typing import Optional, List


class CommentBase(BaseModel):
    content: str = Field(..., example="This is a comment.")
    author_id: int = Field(..., description="ID of the user who wrote the comment")
    record_type: str = Field(..., description="Type of record the comment is attached to (e.g. company, person, order)")
    record_id: int = Field(..., description="ID of the record the comment is attached to")
    mentions: Optional[List[int]] = Field(default_factory=list, description="List of user IDs mentioned in the comment")


class CommentCreate(CommentBase):
    pass


class CommentUpdate(BaseModel):
    content: Optional[str] = None
    mentions: Optional[List[int]] = None


class Comment(CommentBase):
    id: int
    seen_by: List[int] = Field(default_factory=list, description="Users who have seen this comment")

    class Config:
        orm_mode = True
