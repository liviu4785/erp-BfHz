from pydantic import BaseModel, Field
from typing import Optional


class UserBase(BaseModel):
    """Shared properties for a user."""

    name: str = Field(..., example="John Doe")
    email: str = Field(..., example="john@example.com")
    role_id: Optional[int] = Field(None, description="Role assigned to this user")


class UserCreate(UserBase):
    """Properties required when creating a user."""

    password: str = Field(..., min_length=6, example="secret123")


class UserUpdate(BaseModel):
    """Properties that can be updated for a user."""

    name: Optional[str] = None
    email: Optional[str] = None
    role_id: Optional[int] = None


class User(UserBase):
    """User returned to clients."""

    id: int

    class Config:
        orm_mode = True
