from pydantic import BaseModel, Field
from typing import Optional


class InventoryItemBase(BaseModel):
    product_id: int = Field(..., description="ID of the product")
    quantity: int = Field(..., ge=0, description="Current quantity in stock")
    reserved: Optional[int] = Field(0, ge=0, description="Reserved quantity for orders")


class InventoryItemCreate(InventoryItemBase):
    pass


class InventoryItemUpdate(BaseModel):
    quantity: Optional[int] = None
    reserved: Optional[int] = None


class InventoryItem(InventoryItemBase):
    id: int

    class Config:
        orm_mode = True
