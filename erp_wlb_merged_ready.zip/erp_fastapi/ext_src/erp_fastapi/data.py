"""In‑memory data stores.

These dictionaries act as temporary databases for the ERP skeleton.
Each entity type has its own store keyed by a numeric identifier.  In
a real application you should replace these with calls into a
persistent datastore (SQLAlchemy models, ORM queries, etc.).

The stores are shared across routers by importing from this module.
"""

from typing import Dict, Any

# Auto‑incrementing IDs for each entity type.  These counters are used
# to assign unique IDs when creating new records.  In a real
# implementation the database would handle this for you.
_counters: Dict[str, int] = {
    "users": 1,
    "roles": 1,
    "companies": 1,
    "people": 1,
    "products": 1,
    "inventory": 1,
    "orders": 1,
    "comments": 1,
    "documents": 1,
    "addresses": 1,
}


def _next_id(entity: str) -> int:
    """Return the next ID for the given entity and increment the counter."""
    current = _counters.get(entity, 1)
    _counters[entity] = current + 1
    return current


def generate_id(entity: str) -> int:
    """Public helper to generate a unique ID for an entity."""
    return _next_id(entity)


# Data stores
users: Dict[int, Dict[str, Any]] = {}
roles: Dict[int, Dict[str, Any]] = {}
companies: Dict[int, Dict[str, Any]] = {}
people: Dict[int, Dict[str, Any]] = {}
products: Dict[int, Dict[str, Any]] = {}
inventory: Dict[int, Dict[str, Any]] = {}
orders: Dict[int, Dict[str, Any]] = {}
comments_store: Dict[int, Dict[str, Any]] = {}
documents_store: Dict[int, Dict[str, Any]] = {}
addresses_store: Dict[int, Dict[str, Any]] = {}


def clear_all():
    """Clear all data stores (useful for tests)."""
    for store in [users, roles, companies, people, products, inventory, orders, comments_store, documents_store, addresses_store]:
        store.clear()
    for key in _counters:
        _counters[key] = 1
