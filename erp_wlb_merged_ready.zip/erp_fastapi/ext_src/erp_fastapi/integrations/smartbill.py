"""Stub functions for SmartBill integration.

SmartBill provides REST APIs for creating invoices, syncing stock,
retrieving PDF documents, etc.  These stubs act as placeholders
until you implement the actual API calls.
"""

from typing import Dict, Any


def create_invoice(order: Dict[str, Any]) -> str:
    """Create an invoice in SmartBill for the given order.

    Args:
        order: dictionary containing order data (customer, items, totals, etc.)

    Returns:
        The invoice identifier or URL in SmartBill.
    """
    # TODO: send HTTP request to SmartBill API and return invoice ID/URL
    return "INVOICE_ID"


def fetch_invoice_pdf(invoice_id: str) -> bytes:
    """Download the PDF of an invoice from SmartBill.

    Args:
        invoice_id: SmartBill invoice identifier

    Returns:
        The raw PDF bytes.
    """
    # TODO: send HTTP GET to SmartBill API to fetch PDF
    return b""


def sync_stock_to_smartbill(product_id: int, quantity: int) -> None:
    """Sync the stock of a product to SmartBill.

    Args:
        product_id: internal product ID
        quantity: available quantity to sync
    """
    # TODO: implement API call to SmartBill for stock sync
    return None
