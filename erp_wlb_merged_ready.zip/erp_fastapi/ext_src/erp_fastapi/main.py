"""Main FastAPI application.

This module wires together the routers defined in the `routers` package,
adds CORS middleware and defines a global search endpoint.  It uses
in‑memory stores defined in `data.py`.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List

from erp_fastapi import data
from erp_fastapi.models.company import Company
from erp_fastapi.models.person import Person
from erp_fastapi.models.product import Product

from erp_fastapi.routers import (
    users,
    roles,
    companies,
    people,
    products,
    inventory,
    orders,
    comments,
    documents,
    addresses,
)


app = FastAPI(title="ERP FastAPI", version="0.1.0")

# CORS middleware: adjust origins in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(users.router)
app.include_router(roles.router)
app.include_router(companies.router)
app.include_router(people.router)
app.include_router(products.router)
app.include_router(inventory.router)
app.include_router(orders.router)
app.include_router(comments.router)
app.include_router(documents.router)
app.include_router(addresses.router)


@app.get("/")
def read_root() -> dict:
    return {"message": "Welcome to the ERP FastAPI. See /docs for API documentation."}


@app.get("/search", response_model=List[dict])
def global_search(q: str) -> List[dict]:
    """Perform a global search across companies, people and products.

    Returns a list of objects with keys `type` and `result`.  In a real
    implementation this could support pagination and more entity types.
    """
    q_lower = q.lower()
    results: List[dict] = []
    # Search companies
    for company in data.companies.values():
        if q_lower in company["name"].lower():
            results.append({"type": "company", "result": Company(**company)})
    # Search people
    for person in data.people.values():
        full_name = f"{person['first_name']} {person['last_name']}"
        if q_lower in full_name.lower():
            results.append({"type": "person", "result": Person(**person)})
    # Search products
    for product in data.products.values():
        if q_lower in product["name"].lower() or (product.get("code") and q_lower in product["code"].lower()):
            results.append({"type": "product", "result": Product(**product)})
    return results
