# ERP FastAPI Skeleton

This repository contains a **starter implementation** for an ERP system
built with **FastAPI**.  It is intentionally minimal and modular,
designed to grow as new features are added.  The goal of this
project is to provide a clean foundation on which to implement the
large set of requirements described in the project brief (inventory
management, sales, purchasing, finance, documents, comments,
notifications, webshop integration, SmartBill and eMAG integration,
etc.).

## Structure

```
erp_fastapi/
├── main.py              # FastAPI application definition
├── data.py              # In‑memory data stores (to be replaced by a real DB)
├── models/              # Pydantic models for API schemas
│   ├── user.py
│   ├── role.py
│   ├── company.py
│   ├── person.py
│   ├── product.py
│   ├── inventory.py
│   ├── order.py
│   ├── comment.py
│   ├── document.py
│   └── address.py
├── routers/             # API routers grouped by domain
│   ├── users.py
│   ├── roles.py
│   ├── companies.py
│   ├── people.py
│   ├── products.py
│   ├── inventory.py
│   ├── orders.py
│   ├── comments.py
│   ├── documents.py
│   └── addresses.py
├── integrations/        # Stubs for external integrations (eMAG, SmartBill)
│   ├── emag.py
│   └── smartbill.py
└── requirements.txt     # Python package requirements
```

## Quick start

This project uses Python ≥ 3.8 and FastAPI.  No external database is
required for the basic skeleton; all data is stored in memory via
`erp_fastapi/data.py`.  For any real deployment you should replace the
in‑memory storage with a persistent datastore (e.g. SQLAlchemy,
PostgreSQL, or another database engine).

1.  Create a virtual environment (optional but recommended):

    ```bash
    python -m venv .venv
    source .venv/bin/activate
    ```

2.  Install dependencies:

    ```bash
    pip install -r requirements.txt
    ```

3.  Run the development server:

    ```bash
    uvicorn erp_fastapi.main:app --reload
    ```

4.  Browse the auto‑generated API docs at `http://localhost:8000/docs`.

## Next steps

This skeleton is only a starting point.  To build a full ERP you
should:

- Replace the in‑memory `data.py` stores with a real database layer
  (SQLAlchemy, Tortoise ORM, etc.).
- Flesh out the models in `models/` with all fields required by your
  domain (companies, persons, products, stock, orders, invoices, etc.).
- Add authentication and authorization (e.g. JWT tokens).
- Integrate with SmartBill and eMAG by implementing the stubs in
  `integrations/`.
- Implement background tasks for import/export, notifications, and
  scheduled jobs (using Celery or FastAPI background tasks).
- Create a `.env` file based on `.env.local` to configure API
  credentials for eMAG and SmartBill.  The sample file in the
  repository (`.env.local`) shows how to set variables such as
  `EMAG_API_CODE`, `SMARTBILL_EMAIL`, `SMARTBILL_TOKEN` and
  `SMARTBILL_CIF`.
- Build a frontend (e.g. Vue.js) that consumes these APIs and provides
  a responsive, single page user interface.
