"""ERP FastAPI package.

This package contains the FastAPI application and related modules.
"""