"""ERP FastAPI package ready for cPanel/Passenger."""
