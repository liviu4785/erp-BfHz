import importlib, pkgutil
from fastapi import FastAPI

app = FastAPI(title="ERP WLB", version="1.0.0")

@app.get("/")
def root():
    return {"ok": True, "app": "ERP WLB", "version": "1.0.0"}

@app.get("/health")
def health():
    return {"status": "healthy"}

def _include_dynamic_routers():
    try:
        import erp_fastapi.ext_src as ext_pkg
    except Exception:
        return
    for m in pkgutil.walk_packages(ext_pkg.__path__, ext_pkg.__name__ + "."):
        try:
            mod = importlib.import_module(m.name)
        except Exception:
            continue
        router = getattr(mod, "router", None)
        if router is not None:
            try:
                app.include_router(router)
            except Exception:
                pass

_include_dynamic_routers()
